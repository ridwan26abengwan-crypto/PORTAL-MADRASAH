# Server Portal GTK MI Darussalam

Server (backend) berbasis Node.js, Express, dan SQLite. Satu program ini melayani halaman web (folder `public`) sekaligus API-nya. Database tersimpan pada satu berkas, sehingga tidak perlu memasang MySQL atau PostgreSQL terpisah.

## Isi folder

| Berkas | Fungsi |
|---|---|
| `server.js` | Server dan seluruh API |
| `db.js` | Pembuatan tabel dan akun admin pertama |
| `public/index.html`, `public/app.js` | Tampilan portal (landing, login, panel admin, panel guru) |
| `.env.example` | Contoh pengaturan |

## Kebutuhan

- Node.js versi 18 atau lebih baru (disarankan 20 atau 22)
- Hosting atau VPS yang mendukung Node.js, misalnya VPS Linux atau cPanel dengan fitur "Setup Node.js App"

## Cara menjalankan

1. Pasang dependensi: `npm install`
2. Salin `.env.example` menjadi `.env`, lalu isi `JWT_SECRET` dengan teks acak. Cara membuatnya:
   `node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"`
3. (Opsional) isi `ADMIN_PASSWORD`. Bila dikosongkan, password admin awal dibuat acak dan ditampilkan sekali di layar.
4. Jalankan: `npm start`
5. Buka `http://localhost:3000`, masuk dengan username `admin`, lalu ganti password saat diminta.

## Alur penggunaan

1. Admin masuk, lalu mengisi **Data GTK**.
2. Admin membuat **Akun Pengguna** untuk setiap guru dan menghubungkannya ke data GTK masing-masing.
3. Admin mengisi **Jadwal** dan **Pengumuman**.
4. Guru masuk dengan akun dari admin, mengganti password, lalu melengkapi profil.

## Pemasangan di VPS (ringkas)

1. Unggah folder ini ke server, jalankan `npm install --omit=dev`.
2. Jalankan terus-menerus dengan PM2: `npm i -g pm2` lalu `pm2 start server.js --name portal-mi` dan `pm2 save`.
3. Pasang Nginx sebagai reverse proxy ke port 3000, lalu pasang sertifikat HTTPS (misalnya Let’s Encrypt dengan Certbot). Pada `.env`, `NODE_ENV=production` membuat cookie login hanya dikirim lewat HTTPS, jadi HTTPS wajib aktif.

## Pencadangan (backup)

Seluruh data ada di `data/portal.db`. Salin berkas itu (beserta `portal.db-wal` bila ada) secara berkala, atau jalankan `sqlite3 data/portal.db ".backup cadangan.db"`.

## Daftar API

| Metode dan alamat | Akses |
|---|---|
| `GET /api/stats` | Publik |
| `POST /api/login`, `POST /api/logout` | Publik |
| `GET /api/me`, `POST /api/ganti-password` | Login |
| `GET /api/pengumuman` | Login |
| `POST`, `DELETE /api/pengumuman` | Admin |
| `GET /api/jadwal` | Login (guru hanya melihat jadwalnya) |
| `POST`, `DELETE /api/jadwal` | Admin |
| `GET`, `PUT /api/profil` | Login (data GTK milik sendiri) |
| `GET`, `POST`, `PUT`, `DELETE /api/gtk` | Admin |
| `GET`, `POST /api/users`, `PUT /api/users/:id/reset`, `PUT /api/users/:id/aktif` | Admin |

## Fitur keamanan

- Password disimpan sebagai hash bcrypt, tidak pernah dalam bentuk asli.
- Sesi login memakai token JWT di cookie `httpOnly` dan `sameSite=strict`, berlaku 8 jam.
- Hak akses diperiksa di server pada setiap permintaan, sehingga guru tidak dapat mengakses fitur admin. Akun yang dinonaktifkan langsung tidak bisa dipakai.
- Pembatasan login: 10 percobaan per 15 menit per alamat IP.
- Seluruh perintah database memakai parameter (aman dari SQL injection), dan tampilan meng-escape teks (aman dari XSS).
- Header keamanan dan Content Security Policy dipasang lewat Helmet.
- Pengguna baru dan akun yang password-nya direset wajib menggantinya saat masuk.

## Batasan yang perlu diketahui

- SQLite cocok untuk skala madrasah. Jalankan hanya satu proses server agar tidak terjadi benturan penulisan.
- Belum ada fitur "lupa password" lewat email. Reset dilakukan admin pada menu Akun Pengguna.
- Sebelum dipakai dengan data asli, sebaiknya server diuji dan diperiksa oleh orang yang paham keamanan web.
