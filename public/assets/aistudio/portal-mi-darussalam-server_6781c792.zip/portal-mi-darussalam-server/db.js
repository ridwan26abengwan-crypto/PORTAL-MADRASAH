const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const dir = process.env.DATA_DIR || path.join(__dirname, 'data');
fs.mkdirSync(dir, { recursive: true });
const db = new Database(path.join(dir, 'portal.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS gtk (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nama TEXT NOT NULL,
  nuptk TEXT DEFAULT '',
  jabatan TEXT DEFAULT 'Guru',
  status TEXT DEFAULT 'GTT',
  hp TEXT DEFAULT '',
  mapel TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('admin','guru')),
  nama TEXT NOT NULL,
  gtk_id INTEGER REFERENCES gtk(id) ON DELETE SET NULL,
  aktif INTEGER NOT NULL DEFAULT 1,
  wajib_ganti INTEGER NOT NULL DEFAULT 0,
  dibuat TEXT NOT NULL DEFAULT (datetime('now'))
);
CREATE TABLE IF NOT EXISTS pengumuman (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  judul TEXT NOT NULL,
  isi TEXT DEFAULT '',
  tanggal TEXT NOT NULL DEFAULT (date('now'))
);
CREATE TABLE IF NOT EXISTS jadwal (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  gtk_id INTEGER NOT NULL REFERENCES gtk(id) ON DELETE CASCADE,
  hari TEXT NOT NULL,
  jam TEXT NOT NULL,
  mapel TEXT NOT NULL,
  kelas TEXT NOT NULL
);
`);

// Buat akun admin pertama kali server dijalankan
function seedAdmin() {
  const ada = db.prepare('SELECT COUNT(*) c FROM users').get().c;
  if (ada > 0) return;
  const sandi = process.env.ADMIN_PASSWORD || crypto.randomBytes(6).toString('base64url');
  db.prepare('INSERT INTO users (username,password_hash,role,nama,wajib_ganti) VALUES (?,?,?,?,1)')
    .run('admin', bcrypt.hashSync(sandi, 10), 'admin', 'Administrator');
  console.log('\n==============================================');
  console.log(' Akun admin pertama dibuat');
  console.log(' Username : admin');
  console.log(' Password : ' + sandi);
  console.log(' Segera masuk dan ganti password Anda.');
  console.log('==============================================\n');
}
seedAdmin();

module.exports = db;
