var user = null, page = 'dash';
var HARI = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];
function $(s) { return document.querySelector(s); }
function esc(t) { return String(t == null ? '' : t).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); }
function val(id) { return $('#' + id).value.trim(); }
function toast(m) { var t = $('#toast'); t.textContent = m; t.classList.remove('hide'); setTimeout(function () { t.classList.add('hide'); }, 2600); }
function toggleTheme() { var r = document.documentElement, d = r.getAttribute('data-theme') === 'dark' || (!r.getAttribute('data-theme') && matchMedia('(prefers-color-scheme:dark)').matches); r.setAttribute('data-theme', d ? 'light' : 'dark'); }

async function api(path, method, body) {
  var r = await fetch('/api' + path, { method: method || 'GET', headers: body ? { 'Content-Type': 'application/json' } : {}, body: body ? JSON.stringify(body) : undefined, credentials: 'same-origin' });
  var d = await r.json().catch(function () { return {}; });
  if (!r.ok) {
    if (r.status === 401 && user && path !== '/login') { user = null; go('loginv'); }
    throw new Error(d.error || 'Terjadi kesalahan');
  }
  return d;
}
function jalan(fn) { return function () { var a = arguments; return fn.apply(null, a).catch(function (e) { toast(e.message); }); }; }

function go(v) { ['landing', 'loginv', 'appv'].forEach(function (i) { $('#' + i).classList.toggle('hide', i !== v); }); window.scrollTo(0, 0); if (v === 'landing') stats(); }
async function stats() {
  var s = { gtk: '–', pengumuman: '–' };
  try { s = await api('/stats'); } catch (e) { }
  $('#lstats').innerHTML = [['👥', s.gtk, 'Guru dan Tendik'], ['📚', '6', 'Rombongan Belajar'], ['🏫', 'MI', 'Madrasah Ibtidaiyah'], ['📢', s.pengumuman, 'Pengumuman']].map(function (a) { return '<div class="stat"><b>' + a[0] + ' ' + a[1] + '</b><span>' + a[2] + '</span></div>'; }).join('');
}

var login = jalan(async function () {
  $('#err').textContent = '';
  try { user = await api('/login', 'POST', { username: val('u'), password: $('#p').value }); }
  catch (e) { $('#err').textContent = e.message; return; }
  $('#p').value = ''; page = 'dash'; go('appv'); shell();
  if (user.wajib_ganti) { nav('sandi'); toast('Silakan ganti password Anda terlebih dahulu'); }
});
var logout = jalan(async function () { await api('/logout', 'POST'); user = null; go('landing'); });

function shell() {
  var isA = user.role === 'admin';
  var m = isA ? [['dash', '▦', 'Dashboard'], ['gtk', '👥', 'Data GTK'], ['akun', '🔑', 'Akun Pengguna'], ['jadwal', '🗓️', 'Jadwal'], ['info', '📢', 'Pengumuman'], ['sandi', '🔒', 'Ganti Password']]
    : [['dash', '▦', 'Dashboard'], ['profil', '🪪', 'Profil Saya'], ['jadwal', '🗓️', 'Jadwal Mengajar'], ['info', '📢', 'Pengumuman'], ['sandi', '🔒', 'Ganti Password']];
  $('#side').innerHTML = '<div class="brand"><div class="logo">🕌</div><div>MI Darussalam<small>Panel ' + (isA ? 'Admin' : 'Guru') + '</small></div></div>' +
    m.map(function (a) { return '<a data-p="' + a[0] + '" onclick="nav(\'' + a[0] + '\')"><span>' + a[1] + '</span>' + a[2] + '</a>'; }).join('');
  $('#who').innerHTML = '<span class="pill">' + (isA ? 'Admin' : 'Guru') + '</span> ' + esc(user.nama);
  nav(page);
}
var TITLES = { dash: 'Dashboard', gtk: 'Data GTK', akun: 'Akun Pengguna', jadwal: 'Jadwal', info: 'Pengumuman', profil: 'Profil Saya', sandi: 'Ganti Password' };
var nav = jalan(async function (p) {
  page = p;
  document.querySelectorAll('#side a').forEach(function (a) { a.classList.toggle('on', a.dataset.p === p); });
  $('#ttl').textContent = TITLES[p];
  $('#view').innerHTML = '<p>Memuat...</p>';
  var v = { dash: vDash, gtk: vGtk, akun: vAkun, jadwal: vJadwal, info: vInfo, profil: vProfil, sandi: vSandi }[p];
  $('#view').innerHTML = await v();
});

function annList(list, del) {
  return list.map(function (a) { return '<div class="ann"><b>' + esc(a.judul) + '</b><br><small>' + esc(a.tanggal) + '</small><p style="margin:.3rem 0">' + esc(a.isi) + '</p>' + (del ? '<button class="btn del sm" onclick="delAnn(' + a.id + ')">Hapus</button>' : '') + '</div>'; }).join('') || '<p>Belum ada pengumuman.</p>';
}
function opt(list, key, label, sel) { return list.map(function (x) { return '<option value="' + x[key] + '"' + (x[key] == sel ? ' selected' : '') + '>' + esc(x[label]) + '</option>'; }).join(''); }

// ----- Dashboard -----
async function vDash() {
  var ann = await api('/pengumuman');
  if (user.role === 'admin') {
    var g = await api('/gtk'), us = await api('/users');
    var guru = g.filter(function (x) { return /guru/i.test(x.jabatan); }).length;
    return '<div class="stats" style="margin:0 0 1rem"><div class="stat"><b>' + g.length + '</b><span>Total GTK</span></div><div class="stat"><b>' + guru + '</b><span>Guru</span></div><div class="stat"><b>' + us.filter(function (u) { return u.aktif; }).length + '</b><span>Akun aktif</span></div><div class="stat"><b>' + ann.length + '</b><span>Pengumuman</span></div></div><div class="card"><h3 style="margin-top:0">Pengumuman Terbaru</h3>' + annList(ann.slice(0, 5), false) + '</div>';
  }
  var h = HARI[(new Date().getDay() + 6) % 7], j = (await api('/jadwal')).filter(function (x) { return x.hari === h; });
  return '<div class="card" style="background:linear-gradient(135deg,var(--pri2),var(--pri));color:#fff;margin-bottom:1rem"><h3 style="margin:0">Assalamu’alaikum, ' + esc(user.nama) + '</h3><p style="margin:.3rem 0 0">Selamat datang di Portal GTK MI Darussalam.</p></div><div class="row"><div class="card"><h3 style="margin-top:0">Jadwal Hari Ini (' + h + ')</h3>' + (j.length ? j.map(function (x) { return '<p>🕐 ' + esc(x.jam) + ' · <b>' + esc(x.mapel) + '</b> (' + esc(x.kelas) + ')</p>'; }).join('') : '<p>Tidak ada jadwal mengajar hari ini.</p>') + '</div><div class="card"><h3 style="margin-top:0">Pengumuman</h3>' + annList(ann.slice(0, 5), false) + '</div></div>';
}

// ----- Data GTK (admin) -----
var GTK = [];
async function vGtk() {
  GTK = await api('/gtk');
  return '<div class="card"><div class="bar"><input id="q" placeholder="🔍 Cari nama atau jabatan..." oninput="filt()" style="max-width:300px"><button class="btn" onclick="formGtk()">+ Tambah GTK</button></div><div id="form"></div><div class="tw"><table><thead><tr><th>No</th><th>Nama</th><th>NUPTK</th><th>Jabatan</th><th>Status</th><th>No. HP</th><th>Aksi</th></tr></thead><tbody id="tb">' + rowsGtk(GTK) + '</tbody></table></div></div>';
}
function rowsGtk(a) {
  return a.map(function (g, i) { return '<tr><td>' + (i + 1) + '</td><td>' + esc(g.nama) + '</td><td>' + esc(g.nuptk) + '</td><td>' + esc(g.jabatan) + '</td><td><span class="pill">' + esc(g.status) + '</span></td><td>' + esc(g.hp) + '</td><td><button class="btn ghost sm" onclick="formGtk(' + g.id + ')">Ubah</button> <button class="btn del sm" onclick="delGtk(' + g.id + ')">Hapus</button></td></tr>'; }).join('') || '<tr><td colspan="7">Data tidak ditemukan.</td></tr>';
}
function filt() { var q = $('#q').value.toLowerCase(); $('#tb').innerHTML = rowsGtk(GTK.filter(function (g) { return (g.nama + g.jabatan).toLowerCase().indexOf(q) > -1; })); }
function formGtk(id) {
  var g = GTK.filter(function (x) { return x.id === id; })[0] || { nama: '', nuptk: '', jabatan: 'Guru', status: 'GTT', hp: '', mapel: '' };
  $('#form').innerHTML = '<div class="row" style="margin-bottom:1rem"><div><label>Nama Lengkap</label><input id="fn" value="' + esc(g.nama) + '"></div><div><label>NUPTK</label><input id="fk" value="' + esc(g.nuptk) + '"></div><div><label>Jabatan</label><input id="fj" value="' + esc(g.jabatan) + '"></div><div><label>Status</label><select id="fs">' + ['PNS', 'GTY', 'GTT', 'PTT'].map(function (s) { return '<option' + (s === g.status ? ' selected' : '') + '>' + s + '</option>'; }).join('') + '</select></div><div><label>No. HP</label><input id="fh" value="' + esc(g.hp) + '"></div><div><label>Mata Pelajaran</label><input id="fm" value="' + esc(g.mapel) + '"></div></div><button class="btn" onclick="saveGtk(' + (id || 0) + ')">Simpan</button> <button class="btn ghost" onclick="$(\'#form\').innerHTML=\'\'">Batal</button><br><br>';
}
var saveGtk = jalan(async function (id) {
  var b = { nama: val('fn'), nuptk: val('fk'), jabatan: val('fj'), status: val('fs'), hp: val('fh'), mapel: val('fm') };
  await api(id ? '/gtk/' + id : '/gtk', id ? 'PUT' : 'POST', b); toast('Data GTK tersimpan'); nav('gtk');
});
var delGtk = jalan(async function (id) { if (confirm('Hapus data GTK ini beserta jadwalnya?')) { await api('/gtk/' + id, 'DELETE'); nav('gtk'); } });

// ----- Akun pengguna (admin) -----
async function vAkun() {
  var r = await Promise.all([api('/users'), api('/gtk')]), us = r[0], g = r[1];
  return '<div class="card" style="margin-bottom:1rem"><h3 style="margin-top:0">Buat Akun Baru</h3><div class="row"><div><label>Username</label><input id="au" autocomplete="off"></div><div><label>Password awal (min. 8 karakter)</label><input id="ap" type="text" autocomplete="off"></div><div><label>Peran</label><select id="ar"><option value="guru">Guru</option><option value="admin">Admin</option></select></div><div><label>Hubungkan ke data GTK</label><select id="ag"><option value="">— tidak ada —</option>' + opt(g, 'id', 'nama') + '</select></div></div><br><button class="btn" onclick="addUser()">Buat Akun</button><p style="color:var(--muted);font-size:.85rem">Pengguna wajib mengganti password saat pertama kali masuk.</p></div><div class="card"><div class="tw"><table><thead><tr><th>Username</th><th>Nama</th><th>Peran</th><th>Data GTK</th><th>Status</th><th>Aksi</th></tr></thead><tbody>' +
    us.map(function (u) { return '<tr><td>' + esc(u.username) + '</td><td>' + esc(u.nama) + '</td><td><span class="pill">' + u.role + '</span></td><td>' + esc(u.gtk_nama || '-') + '</td><td>' + (u.aktif ? 'Aktif' : 'Nonaktif') + '</td><td><button class="btn ghost sm" onclick="resetUser(' + u.id + ')">Reset password</button> <button class="btn del sm" onclick="aktifUser(' + u.id + ',' + (u.aktif ? 0 : 1) + ')">' + (u.aktif ? 'Nonaktifkan' : 'Aktifkan') + '</button></td></tr>'; }).join('') + '</tbody></table></div></div>';
}
var addUser = jalan(async function () {
  var g = val('ag');
  await api('/users', 'POST', { username: val('au'), password: val('ap'), role: val('ar'), gtk_id: g ? Number(g) : null });
  toast('Akun dibuat'); nav('akun');
});
var resetUser = jalan(async function (id) {
  var p = prompt('Masukkan password baru (minimal 8 karakter):'); if (!p) return;
  await api('/users/' + id + '/reset', 'PUT', { password: p }); toast('Password direset');
});
var aktifUser = jalan(async function (id, a) { await api('/users/' + id + '/aktif', 'PUT', { aktif: !!a }); nav('akun'); });

// ----- Jadwal -----
async function vJadwal() {
  var j = await api('/jadwal'), isA = user.role === 'admin', g = isA ? await api('/gtk') : [];
  var form = isA ? '<div class="card" style="margin-bottom:1rem"><h3 style="margin-top:0">Tambah Jadwal</h3><div class="row"><div><label>Guru</label><select id="jg">' + opt(g, 'id', 'nama') + '</select></div><div><label>Hari</label><select id="jh">' + HARI.map(function (h) { return '<option>' + h + '</option>'; }).join('') + '</select></div><div><label>Jam</label><input id="jj" placeholder="07.00–08.10"></div><div><label>Mata Pelajaran</label><input id="jm"></div><div><label>Kelas</label><input id="jk" placeholder="Kelas 3"></div></div><br><button class="btn" onclick="addJadwal()">Tambah</button></div>' : '';
  return form + '<div class="card"><div class="tw"><table><thead><tr><th>Hari</th><th>Jam</th><th>Mata Pelajaran</th><th>Kelas</th>' + (isA ? '<th>Guru</th><th>Aksi</th>' : '') + '</tr></thead><tbody>' +
    (j.map(function (x) { return '<tr><td>' + esc(x.hari) + '</td><td>' + esc(x.jam) + '</td><td>' + esc(x.mapel) + '</td><td>' + esc(x.kelas) + '</td>' + (isA ? '<td>' + esc(x.guru) + '</td><td><button class="btn del sm" onclick="delJadwal(' + x.id + ')">Hapus</button></td>' : '') + '</tr>'; }).join('') || '<tr><td colspan="6">Belum ada jadwal.</td></tr>') + '</tbody></table></div></div>';
}
var addJadwal = jalan(async function () {
  await api('/jadwal', 'POST', { gtk_id: Number(val('jg')), hari: val('jh'), jam: val('jj'), mapel: val('jm'), kelas: val('jk') }); toast('Jadwal ditambahkan'); nav('jadwal');
});
var delJadwal = jalan(async function (id) { await api('/jadwal/' + id, 'DELETE'); nav('jadwal'); });

// ----- Pengumuman -----
async function vInfo() {
  var a = await api('/pengumuman'), isA = user.role === 'admin';
  return (isA ? '<div class="card" style="margin-bottom:1rem"><h3 style="margin-top:0">Buat Pengumuman</h3><label>Judul</label><input id="at"><label>Isi</label><input id="ad"><br><br><button class="btn" onclick="addAnn()">Publikasikan</button></div>' : '') + '<div class="card">' + annList(a, isA) + '</div>';
}
var addAnn = jalan(async function () { await api('/pengumuman', 'POST', { judul: val('at'), isi: val('ad') }); toast('Pengumuman dipublikasikan'); nav('info'); });
var delAnn = jalan(async function (id) { await api('/pengumuman/' + id, 'DELETE'); nav('info'); });

// ----- Profil guru -----
async function vProfil() {
  var p;
  try { p = await api('/profil'); } catch (e) { return '<div class="card"><p>' + esc(e.message) + '</p></div>'; }
  return '<div class="card" style="max-width:560px"><label>Nama Lengkap</label><input id="pn" value="' + esc(p.nama) + '"><label>NUPTK</label><input id="pk" value="' + esc(p.nuptk) + '"><label>No. HP</label><input id="ph" value="' + esc(p.hp) + '"><label>Mata Pelajaran / Tugas</label><input id="pm" value="' + esc(p.mapel) + '"><br><br><button class="btn" onclick="saveProfil()">Simpan Profil</button></div>';
}
var saveProfil = jalan(async function () {
  await api('/profil', 'PUT', { nama: val('pn'), nuptk: val('pk'), hp: val('ph'), mapel: val('pm') });
  user.nama = val('pn'); $('#who').innerHTML = '<span class="pill">Guru</span> ' + esc(user.nama); toast('Profil tersimpan');
});

// ----- Ganti password -----
async function vSandi() {
  return '<div class="card" style="max-width:460px">' + (user.wajib_ganti ? '<p class="ann">Demi keamanan, ganti password sementara Anda sebelum melanjutkan.</p>' : '') + '<label>Password lama</label><input id="sl" type="password" autocomplete="current-password"><label>Password baru (minimal 8 karakter)</label><input id="sb" type="password" autocomplete="new-password"><label>Ulangi password baru</label><input id="su" type="password" autocomplete="new-password"><br><br><button class="btn" onclick="gantiSandi()">Ganti Password</button></div>';
}
var gantiSandi = jalan(async function () {
  if ($('#sb').value !== $('#su').value) { toast('Ulangi password tidak sama'); return; }
  await api('/ganti-password', 'POST', { lama: $('#sl').value, baru: $('#sb').value });
  user.wajib_ganti = false; toast('Password berhasil diganti'); nav('dash');
});

// ----- Mulai: pulihkan sesi bila masih login -----
(async function () {
  try { user = await api('/me'); go('appv'); shell(); if (user.wajib_ganti) nav('sandi'); }
  catch (e) { user = null; go('landing'); }
})();
