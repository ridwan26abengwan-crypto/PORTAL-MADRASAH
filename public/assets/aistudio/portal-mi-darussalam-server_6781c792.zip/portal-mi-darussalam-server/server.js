require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const rateLimit = require('express-rate-limit');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const path = require('path');
const db = require('./db');

const PROD = process.env.NODE_ENV === 'production';
const SECRET = process.env.JWT_SECRET;
if (!SECRET || SECRET.length < 32) {
  console.error('JWT_SECRET belum diatur atau kurang dari 32 karakter. Lihat file .env.example.');
  process.exit(1);
}
const PORT = process.env.PORT || 3000;
const HARI = ['Senin', 'Selasa', 'Rabu', 'Kamis', 'Jumat', 'Sabtu'];

const app = express();
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      scriptSrc: ["'self'"],
      scriptSrcAttr: ["'unsafe-inline'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      imgSrc: ["'self'", 'data:'],
      upgradeInsecureRequests: PROD ? [] : null
    }
  }
}));
app.use(express.json({ limit: '50kb' }));
app.use(cookieParser());

// ---------- Pembantu ----------
const bersih = (v, max = 200) => String(v ?? '').trim().slice(0, max);
const publicUser = u => ({ id: u.id, username: u.username, role: u.role, nama: u.nama, gtk_id: u.gtk_id, wajib_ganti: !!u.wajib_ganti });
const gagal = (res, kode, pesan) => res.status(kode).json({ error: pesan });

function auth(req, res, next) {
  const t = req.cookies.token;
  if (!t) return gagal(res, 401, 'Belum login');
  try {
    const p = jwt.verify(t, SECRET);
    const u = db.prepare('SELECT * FROM users WHERE id=?').get(p.id);
    if (!u || !u.aktif) throw new Error('nonaktif');
    req.user = u;
    next();
  } catch (e) {
    res.clearCookie('token');
    gagal(res, 401, 'Sesi berakhir, silakan login kembali');
  }
}
const adminSaja = (req, res, next) => req.user.role === 'admin' ? next() : gagal(res, 403, 'Khusus admin');

// ---------- Publik ----------
app.get('/api/stats', (req, res) => {
  res.json({
    gtk: db.prepare('SELECT COUNT(*) c FROM gtk').get().c,
    pengumuman: db.prepare('SELECT COUNT(*) c FROM pengumuman').get().c
  });
});

const batasLogin = rateLimit({
  windowMs: 15 * 60 * 1000, max: 10, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Terlalu banyak percobaan login. Coba lagi dalam 15 menit.' }
});
const SANDI_PALSU = bcrypt.hashSync('tidak-dipakai', 10);

app.post('/api/login', batasLogin, (req, res) => {
  const username = bersih(req.body.username, 50).toLowerCase();
  const password = String(req.body.password ?? '');
  const u = db.prepare('SELECT * FROM users WHERE username=?').get(username);
  const cocok = bcrypt.compareSync(password, u ? u.password_hash : SANDI_PALSU);
  if (!u || !u.aktif || !cocok) return gagal(res, 401, 'Username atau password salah');
  const token = jwt.sign({ id: u.id }, SECRET, { expiresIn: '8h' });
  res.cookie('token', token, { httpOnly: true, sameSite: 'strict', secure: PROD, maxAge: 8 * 3600 * 1000 });
  res.json(publicUser(u));
});

app.post('/api/logout', (req, res) => { res.clearCookie('token'); res.json({ ok: true }); });

// ---------- Perlu login ----------
app.get('/api/me', auth, (req, res) => res.json(publicUser(req.user)));

app.post('/api/ganti-password', auth, (req, res) => {
  const lama = String(req.body.lama ?? ''), baru = String(req.body.baru ?? '');
  if (!bcrypt.compareSync(lama, req.user.password_hash)) return gagal(res, 400, 'Password lama salah');
  if (baru.length < 8) return gagal(res, 400, 'Password baru minimal 8 karakter');
  db.prepare('UPDATE users SET password_hash=?, wajib_ganti=0 WHERE id=?').run(bcrypt.hashSync(baru, 10), req.user.id);
  res.json({ ok: true });
});

app.get('/api/pengumuman', auth, (req, res) => {
  res.json(db.prepare('SELECT * FROM pengumuman ORDER BY id DESC').all());
});
app.post('/api/pengumuman', auth, adminSaja, (req, res) => {
  const judul = bersih(req.body.judul, 150);
  if (!judul) return gagal(res, 400, 'Judul wajib diisi');
  const r = db.prepare('INSERT INTO pengumuman (judul,isi) VALUES (?,?)').run(judul, bersih(req.body.isi, 2000));
  res.status(201).json({ id: r.lastInsertRowid });
});
app.delete('/api/pengumuman/:id', auth, adminSaja, (req, res) => {
  db.prepare('DELETE FROM pengumuman WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// Jadwal: admin melihat semua, guru hanya jadwalnya sendiri
app.get('/api/jadwal', auth, (req, res) => {
  const urut = "ORDER BY CASE j.hari WHEN 'Senin' THEN 1 WHEN 'Selasa' THEN 2 WHEN 'Rabu' THEN 3 WHEN 'Kamis' THEN 4 WHEN 'Jumat' THEN 5 ELSE 6 END, j.jam";
  const dasar = 'SELECT j.*, g.nama AS guru FROM jadwal j JOIN gtk g ON g.id=j.gtk_id ';
  if (req.user.role === 'admin') return res.json(db.prepare(dasar + urut).all());
  res.json(db.prepare(dasar + 'WHERE j.gtk_id=? ' + urut).all(req.user.gtk_id ?? -1));
});
app.post('/api/jadwal', auth, adminSaja, (req, res) => {
  const b = req.body, hari = bersih(b.hari, 10);
  if (!HARI.includes(hari) || !b.gtk_id || !bersih(b.jam, 30) || !bersih(b.mapel, 80) || !bersih(b.kelas, 30))
    return gagal(res, 400, 'Lengkapi semua isian jadwal');
  if (!db.prepare('SELECT 1 FROM gtk WHERE id=?').get(b.gtk_id)) return gagal(res, 400, 'Guru tidak ditemukan');
  const r = db.prepare('INSERT INTO jadwal (gtk_id,hari,jam,mapel,kelas) VALUES (?,?,?,?,?)')
    .run(b.gtk_id, hari, bersih(b.jam, 30), bersih(b.mapel, 80), bersih(b.kelas, 30));
  res.status(201).json({ id: r.lastInsertRowid });
});
app.delete('/api/jadwal/:id', auth, adminSaja, (req, res) => {
  db.prepare('DELETE FROM jadwal WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// Profil guru (data GTK milik sendiri)
app.get('/api/profil', auth, (req, res) => {
  const g = req.user.gtk_id && db.prepare('SELECT * FROM gtk WHERE id=?').get(req.user.gtk_id);
  if (!g) return gagal(res, 404, 'Akun ini belum dihubungkan dengan data GTK. Hubungi admin.');
  res.json(g);
});
app.put('/api/profil', auth, (req, res) => {
  if (!req.user.gtk_id) return gagal(res, 404, 'Akun ini belum dihubungkan dengan data GTK. Hubungi admin.');
  const b = req.body, nama = bersih(b.nama, 100);
  if (!nama) return gagal(res, 400, 'Nama wajib diisi');
  db.prepare('UPDATE gtk SET nama=?, nuptk=?, hp=?, mapel=? WHERE id=?')
    .run(nama, bersih(b.nuptk, 30), bersih(b.hp, 20), bersih(b.mapel, 80), req.user.gtk_id);
  db.prepare('UPDATE users SET nama=? WHERE id=?').run(nama, req.user.id);
  res.json({ ok: true });
});

// ---------- Khusus admin: Data GTK ----------
const kolomGtk = b => [bersih(b.nama, 100), bersih(b.nuptk, 30), bersih(b.jabatan, 80) || 'Guru',
  ['PNS', 'GTY', 'GTT', 'PTT'].includes(b.status) ? b.status : 'GTT', bersih(b.hp, 20), bersih(b.mapel, 80)];

app.get('/api/gtk', auth, adminSaja, (req, res) => res.json(db.prepare('SELECT * FROM gtk ORDER BY nama').all()));
app.post('/api/gtk', auth, adminSaja, (req, res) => {
  const k = kolomGtk(req.body);
  if (!k[0]) return gagal(res, 400, 'Nama wajib diisi');
  const r = db.prepare('INSERT INTO gtk (nama,nuptk,jabatan,status,hp,mapel) VALUES (?,?,?,?,?,?)').run(...k);
  res.status(201).json({ id: r.lastInsertRowid });
});
app.put('/api/gtk/:id', auth, adminSaja, (req, res) => {
  const k = kolomGtk(req.body);
  if (!k[0]) return gagal(res, 400, 'Nama wajib diisi');
  db.prepare('UPDATE gtk SET nama=?, nuptk=?, jabatan=?, status=?, hp=?, mapel=? WHERE id=?').run(...k, req.params.id);
  res.json({ ok: true });
});
app.delete('/api/gtk/:id', auth, adminSaja, (req, res) => {
  db.prepare('DELETE FROM gtk WHERE id=?').run(req.params.id);
  res.json({ ok: true });
});

// ---------- Khusus admin: Akun pengguna ----------
app.get('/api/users', auth, adminSaja, (req, res) => {
  res.json(db.prepare('SELECT u.id,u.username,u.nama,u.role,u.aktif,u.gtk_id,g.nama AS gtk_nama FROM users u LEFT JOIN gtk g ON g.id=u.gtk_id ORDER BY u.role,u.username').all());
});
app.post('/api/users', auth, adminSaja, (req, res) => {
  const b = req.body, username = bersih(b.username, 50).toLowerCase(), password = String(b.password ?? '');
  const role = b.role === 'admin' ? 'admin' : 'guru';
  if (!/^[a-z0-9._-]{3,50}$/.test(username)) return gagal(res, 400, 'Username 3–50 karakter: huruf kecil, angka, titik, garis bawah, atau strip');
  if (password.length < 8) return gagal(res, 400, 'Password minimal 8 karakter');
  if (db.prepare('SELECT 1 FROM users WHERE username=?').get(username)) return gagal(res, 409, 'Username sudah dipakai');
  let gtkId = b.gtk_id ? Number(b.gtk_id) : null, nama = bersih(b.nama, 100);
  if (gtkId) {
    const g = db.prepare('SELECT nama FROM gtk WHERE id=?').get(gtkId);
    if (!g) return gagal(res, 400, 'Data GTK tidak ditemukan');
    nama = nama || g.nama;
  }
  if (!nama) return gagal(res, 400, 'Nama wajib diisi');
  const r = db.prepare('INSERT INTO users (username,password_hash,role,nama,gtk_id,wajib_ganti) VALUES (?,?,?,?,?,1)')
    .run(username, bcrypt.hashSync(password, 10), role, nama, gtkId);
  res.status(201).json({ id: r.lastInsertRowid });
});
app.put('/api/users/:id/reset', auth, adminSaja, (req, res) => {
  const password = String(req.body.password ?? '');
  if (password.length < 8) return gagal(res, 400, 'Password minimal 8 karakter');
  db.prepare('UPDATE users SET password_hash=?, wajib_ganti=1 WHERE id=?').run(bcrypt.hashSync(password, 10), req.params.id);
  res.json({ ok: true });
});
app.put('/api/users/:id/aktif', auth, adminSaja, (req, res) => {
  if (Number(req.params.id) === req.user.id) return gagal(res, 400, 'Anda tidak dapat menonaktifkan akun sendiri');
  db.prepare('UPDATE users SET aktif=? WHERE id=?').run(req.body.aktif ? 1 : 0, req.params.id);
  res.json({ ok: true });
});

// ---------- Berkas halaman web ----------
app.use(express.static(path.join(__dirname, 'public')));
app.use('/api', (req, res) => gagal(res, 404, 'Alamat tidak ditemukan'));
app.use((err, req, res, next) => {
  console.error(err);
  gagal(res, err.status || 500, err.status ? 'Permintaan tidak valid' : 'Terjadi kesalahan pada server');
});

app.listen(PORT, () => console.log('Portal MI Darussalam berjalan di http://localhost:' + PORT));
